from django.contrib import admin
from .models import Product


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):

    list_display = ("id", "name", "price", "created_by")

    search_fields = ("name",)

    list_filter = ("created_by",)

    def save_model(self, request, obj, form, change):

        if not obj.created_by:
            obj.created_by = request.user

        super().save_model(request, obj, form, change)